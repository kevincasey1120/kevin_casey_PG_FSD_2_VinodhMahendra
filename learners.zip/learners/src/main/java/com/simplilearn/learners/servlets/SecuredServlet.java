package com.simplilearn.learners.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class SecuredServlet extends HttpServlet {
	   private static final long serialVersionUID = 1L;
	   
	    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        handleRequest(req, resp);
	    }
	 
	    private void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {    
	    	
	    	response.setContentType("text/html");
	 
	        /***** Building & Printing The HTML Response Code *****/
	    	PrintWriter out = response.getWriter();
			response.setContentType("text/html");
	
		     
			RequestDispatcher dispatcher = request.getRequestDispatcher("admin-choice-screen.jsp");
			dispatcher.forward(request, response);  
			
		    out.close(); 
	    }
}
