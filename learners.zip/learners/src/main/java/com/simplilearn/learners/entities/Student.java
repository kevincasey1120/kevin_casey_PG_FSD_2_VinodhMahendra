package com.simplilearn.learners.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="students")
public class Student {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	protected int id;
	
	@Column(name="firstname")
	protected String firstname;
	
	@Column(name="lastname")
	protected String lastname;
	
	@Column(name="gpa")
	protected double gpa;
	
	@Column(name="email")
	protected String email;
	
	@Column(name="classid")
	protected int classid;
	
	
	public Student() {
	}
	
	public Student(String firstname, String lastname, String email, double gpa, int classid) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gpa = gpa;
		this.email = email;
		this.classid = classid;
	}

	public Student(int id, String firstname, String lastname, String email, double gpa, int classid) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.gpa = gpa;
		this.email = email;
		this.classid = classid;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public double getGpa() {
		return gpa;
	}

	public void setGpa(double gpa) {
		this.gpa = gpa;
	}

	public int getClassid() {
		return classid;
	}

	public void setClassid(int classid) {
		this.classid = classid;
	}

}
