package com.simplilearn.learners.mock;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.simplilearn.learners.entities.ClassSession;
import com.simplilearn.learners.entities.Student;
import com.simplilearn.learners.entities.Subject;
import com.simplilearn.learners.entities.Teacher;
import com.simplilearn.learners.util.HibernateUtil;

public class MockDataGen {
	
	Transaction transaction = null;
	
	public MockDataGen() {
	}

	public void createMockData() {
		// ------------------------------
		
		Session session = HibernateUtil.getSessionFactory().openSession();

		// --------------------------------------
		transaction = session.beginTransaction();

		// ------------------------------
		populateSampleData_students(session);
		populateSampleData_teachers(session);
		populateSampleData_classes(session);
		populateSampleData_subjects(session);

		transaction.commit();

	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	public void populateSampleData_students(Session session) {
		// session.beginTransaction();
		// -----------------------------------------------
		session.save(new Student("Mike", "Fischer", "email1@mail.com", 3.2, 1));
		session.save(new Student("Sara", "Jane", "email4@mail.com", 2.7, 2));
		session.save(new Student("Jenny", "Smity", "email3@mail.com", 4.0, 3));
		session.save(new Student("Larry", "Noone", "email2@mail.com", 3.6, 4));
		session.save(new Student("Tara", "Block", "email3@mail.com", 3.0, 5));
		session.save(new Student("Paul", "Jackson", "email4@mail.com", 2.0, 6));
		session.save(new Student("Karala", "Muuse", "email5@mail.com", 3.3, 7));
		session.save(new Student("Simon", "Sayas", "email6@mail.com", 3.5, 8));
		session.save(new Student("Gill", "Jones", "email7@mail.com", 3.2, 9));
		session.save(new Student("Ron", "Mako", "email8@mail.com", 3.2, 1));
		session.save(new Student("Peter", "Torrance", "email9@mail.com", 2.1, 2));
		session.save(new Student("Megan", "Gothers", "email10@mail.com", 2.8, 3));
		session.save(new Student("William", "Sanders", "email10@mail.com", 3.3, 4));
		session.save(new Student("Kevin", "Dabest", "email11@mail.com", 3.9, 5));
		session.save(new Student("Flavo", "Flayve", "email12@mail.com", 3.1, 6));
		session.save(new Student("Jeremy", "Schillinger", "email13@mail.com", 2.8, 7));
		session.save(new Student("Mary", "Margarrete", "email14@mail.com", 3.8, 8));
		session.save(new Student("Olive", "Hammer", "email14@mail.com", 3.4, 1));
		session.save(new Student("Sillio", "Hillare", "email15@mail.com", 3.2, 2));
		session.save(new Student("Tim", "Theenks", "email16@mail.com", 2.5, 3));
		session.save(new Student("Samwell", "Tarley", "email17@mail.com", 3.7, 4));
		// -----------------------------------------------

	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	public void populateSampleData_teachers(Session session) {
		// session.beginTransaction();
		// -----------------------------------------------
		session.save(new Teacher("Mr.", "Joe", "Cool", "email1@mail.com"));
		session.save(new Teacher("Mrs.", "Carla", "Smith", "email2@mail.com"));
		session.save(new Teacher("Ms.", "Alexandria", "Hamilton", "email3@mail.com"));
		session.save(new Teacher("Sr.", "John", "Snow", "email4@mail.com"));
		session.save(new Teacher("Mr.", "Henry", "Hand", "email5@mail.com"));
		session.save(new Teacher("Mrs.", "Gloria", "Smithers", "email6@mail.com"));
		// -----------------------------------------------
		// session.getTransaction().commit();

	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	public void populateSampleData_classes(Session session) {
		// session.beginTransaction();
		// -----------------------------------------------
		session.save(new ClassSession(1, 1));
		session.save(new ClassSession(2, 2));
		session.save(new ClassSession(3, 9));
		session.save(new ClassSession(4, 4));
		session.save(new ClassSession(1, 5));
		session.save(new ClassSession(5, 8));
		session.save(new ClassSession(5, 11));
		session.save(new ClassSession(4, 3));
		session.save(new ClassSession(6, 12));
		// -----------------------------------------------
		// session.getTransaction().commit();

	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	public void populateSampleData_subjects(Session session) {
		// session.beginTransaction();
		// -----------------------------------------------
		// List<Teacher> objectsList = new ArrayList();
		// -----------------------------------------------
		session.save(new Subject("HomeEc"));
		session.save(new Subject("Physics"));
		session.save(new Subject("Chemistry I"));
		session.save(new Subject("Chemistry II"));
		session.save(new Subject("Biology 101"));
		session.save(new Subject("English 101"));
		session.save(new Subject("English 102"));
		session.save(new Subject("Poly Sci"));
		session.save(new Subject("History"));
		session.save(new Subject("Sociology"));
		session.save(new Subject("PhysEd"));
		session.save(new Subject("Algebra"));
		session.save(new Subject("Computers"));
		session.save(new Subject("Shop"));
		// -----------------------------------------------
		// session.getTransaction().commit();

	}

}
