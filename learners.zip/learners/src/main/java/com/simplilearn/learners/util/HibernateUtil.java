package com.simplilearn.learners.util;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;

import com.simplilearn.learners.entities.ClassSession;
import com.simplilearn.learners.entities.Student;
import com.simplilearn.learners.entities.Subject;
import com.simplilearn.learners.entities.Teacher;



public class HibernateUtil {
	
	private static SessionFactory sessionFactory;
	private static StandardServiceRegistry serviceRegistry;
	
	
	public static SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			try {
				Configuration configuration = new Configuration();

				// Hibernate settings equivalent to hibernate.cfg.xml's properties
				Properties settings = new Properties();
				settings.put(Environment.DRIVER, "com.mysql.jdbc.Driver");
				settings.put(Environment.URL, "jdbc:mysql://localhost:3306/learners?allowPublicKeyRetrieval=true&useSSL=false");
				settings.put(Environment.USER, "root");
				settings.put(Environment.PASS, "secret");
				
				settings.put(Environment.DIALECT, "org.hibernate.dialect.MySQL5Dialect");
				settings.put(Environment.SHOW_SQL, "true");
				settings.put(Environment.CURRENT_SESSION_CONTEXT_CLASS, "thread");
				settings.put(Environment.HBM2DDL_AUTO, "create-drop");

				configuration.setProperties(settings);
				configuration.addAnnotatedClass(ClassSession.class);
				configuration.addAnnotatedClass(Subject.class);
				configuration.addAnnotatedClass(Student.class);
				configuration.addAnnotatedClass(Teacher.class);
				
				//---------------------------------------------
				serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
				
				//---------------------------------------------
				sessionFactory = configuration.buildSessionFactory(serviceRegistry);
				System.out.println("[HibernateUtils]  -- getSessionFactory -- (registry) ");
				
				return sessionFactory;

			} catch (Exception e) {
			
				//---------------------------------------------
				if(sessionFactory == null) {
					System.out.println("\n---------------------------------- [HibernateUtils] <<<<CRITICAL FAILURE >>> -----------------------");
				}
				e.printStackTrace();
				
				//---------------------------------------------
				if ( serviceRegistry != null) {
					StandardServiceRegistryBuilder.destroy(serviceRegistry);
				}
			}
		}
		return sessionFactory;
	}
}
