package com.simplilearn.learners.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.simplilearn.learners.dao.ClassSessionDao;
import com.simplilearn.learners.dao.SubjectDao;
import com.simplilearn.learners.entities.ClassSession;
import com.simplilearn.learners.entities.Subject;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;

@WebServlet("/classsession-servlet")

public class ClassSessionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ClassSessionDao classsessionDao;

	public void init() {
		classsessionDao = new ClassSessionDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = "";

		if (request.getParameterMap() != null && request.getParameterMap().size() > 0) {

			Map<String, String[]> parameters = request.getParameterMap();

			// ---------------------------------------------------
			int subjectid = -1;
			int teacherid = -1;

			// ---------------------------------------------------
			for (String parameter : parameters.keySet()) {

				String[] values = parameters.get(parameter);

				for (String val : values) {

					System.out.println(
							"[ClassSessionServlet]    PARAMETER SET --->  (" + parameter + ")   (" + val + ")");

					if (parameter.equals("subject")) {
						subjectid = Integer.parseInt(val);
						request.setAttribute("subjectid", subjectid);

					} else if (parameter.equals("teacher")) {
						teacherid = Integer.parseInt(val);
						request.setAttribute("teacherid", teacherid);
					}
				}

			}
		} else {
			System.out.println("[ClassSessionServlet]  ---->  NO PARAMETERS ARE SET  <---");
		}

		// ----------------------------------------------------
		if (request.getServletPath() != null && request.getServletPath().equals("list")) {
			action = "list";

		} else {
			if (request.getParameterMap().containsKey("choice")) {
				action = request.getParameter("choice").toString();
			}
		}

		System.out.println("[ClassSessionServlet]   SERVLET ACTION REQUEST is (" + action + ")");

		// ----------------------------------------------------
		if (action.contains("id=")) {
			// --------------------------
			String[] array = action.split("\\?");
			action = array[0];

			// --------------------------
			int id_final = Integer.parseInt(array[1].replace("id=", ""));
			System.out.println("[ClassSessionServlet : doGet]  ----------------    array[0]= " + array[0]
					+ "       id_final= " + id_final);
			request.setAttribute("id", id_final);
		}

		try {
			switch (action) {
			case "report":
				showClassReportForm(request, response);
			case "new":
				showNewForm(request, response);
				break;
			case "insert":
				insertClassSession(request, response);
				break;
			case "delete":
				deleteClassSession(request, response);
				break;
			case "edit":
				showEditForm(request, response);
				break;
			case "update":
				updateClassSession(request, response);
				break;
			case "list":
				listClassSession(request, response);
				break;
			default:
				listClassSession(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	
	private void showClassReportForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int id = (int) request.getAttribute("id");
		
		ClassSession existingClassSession = classsessionDao.getClassSession(id);
	
		if(existingClassSession == null) {
			System.out.println("\n[CLASS SESSION SERVLET]   showClassReportForm  ----------  (existingClassSession) CLASS SESSION IS NULL!!!!!   for (id = "+id+")");
			RequestDispatcher dispatcher = request.getRequestDispatcher("admin-choice-screen.jsp");
			dispatcher.forward(request, response);
			
			
		}else {
			System.out.println("\n[CLASS SESSION SERVLET]   showClassReportForm  ----------  (existingClassSession) CLASS SESSION IS    for (id = "+id+")");
			RequestDispatcher dispatcher = request.getRequestDispatcher("class-report-form.jsp");
			request.setAttribute("classsession", existingClassSession);
			dispatcher.forward(request, response);
		}
	}

	
	
	
	private void listClassSession(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {

		List<ClassSession> listClassSession = classsessionDao.getAllClassSession();

		request.setAttribute("listClassSession", listClassSession);

		RequestDispatcher dispatcher = request.getRequestDispatcher("classsession-records-form.jsp"); 
		dispatcher.forward(request, response);
	}

	
	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if(!response.isCommitted()) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("classsession-records-form.jsp");
			dispatcher.forward(request, response);
		}	

	}
	
	
	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {

		int id = (int) request.getAttribute("id");

		ClassSession existingClassSession = classsessionDao.getClassSession(id);

		RequestDispatcher dispatcher = request.getRequestDispatcher("classsession-records-listing.jsp");
		request.setAttribute("classsession", existingClassSession);
		dispatcher.forward(request, response);
	}
	
	
	

	private void insertClassSession(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException {

		int teacherid = (int) request.getAttribute("teacherid");
		int subjectid = (int) request.getAttribute("subjectid");

		System.out.println("[CLASS SESSION SERVLET]   final teacherid = (" + teacherid + ")    final subjectid = ("
				+ subjectid + ")");

		ClassSession newClassSession = new ClassSession(teacherid, subjectid);
		classsessionDao.saveClassSession(newClassSession);

		RequestDispatcher dispatcher = request.getRequestDispatcher("classsession-records-form.jsp");
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void updateClassSession(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException {

		int id = (int) request.getAttribute("id");

		int teacherid = (int) request.getAttribute("teacherid");
		int subjectid = (int) request.getAttribute("subjectid");

		System.out.println("[CLASS SESSION SERVLET]   final teacherid = (" + teacherid + ")    final subjectid = ("
				+ subjectid + ")");

		ClassSession newClassSession = new ClassSession(id, teacherid, subjectid);
		classsessionDao.updateClassSession(newClassSession);

		RequestDispatcher dispatcher = request.getRequestDispatcher("classsession-records-form.jsp");
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void deleteClassSession(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException {

		int id = (int) request.getAttribute("id");

		classsessionDao.deleteClassSession(id);

		try {
			listClassSession(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}