package com.simplilearn.learners.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.simplilearn.learners.dao.SubjectDao;
import com.simplilearn.learners.entities.Subject;
import com.simplilearn.learners.mock.MockDataGen;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;



@WebServlet("/admin-choice-servlet")

public class AdminChoiceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private SubjectDao subjectDao;
	
	public void init() {
		subjectDao = new SubjectDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		String action = "";

	
		
		//----------------------------------------------------
		if (request.getParameterMap() != null && request.getParameterMap().size() > 0) {

			Map<String, String[]> parameters = request.getParameterMap();

	
			// ---------------------------------------------------
			for (String parameter : parameters.keySet()) {

				String[] values = parameters.get(parameter);

				for (String val : values) {

					System.out.println(
							"[AdminChoiceServlet]    PARAMETER SET --->  (" + parameter + ")   (" + val + ")");
				}

			}
		} else {
			System.out.println("[AdminChoiceServlet]  ---->  NO PARAMETERS ARE SET  <---");
		}
		
		
		
		
		//----------------------------------------------------
	
			if(request.getParameterMap().containsKey("choice")) {
				action = request.getParameter("choice").toString();
			}
		
		

		System.out.println("[AdminChoiceServlet]   SERVLET ACTION REQUEST is ("+action+")");
		
		
		//----------------------------------------------------
		if(action.contains("id=")) {
			//--------------------------
			String[] array = action.split("\\?");
			action = array[0];
			
			//--------------------------
			int id_final = Integer.parseInt(array[1].replace("id=", ""));
			System.out.println("[AdminChoiceServlet : doGet]  ----------------    array[0]= "+array[0]+"       id_final= "+id_final);
			request.setAttribute("id", id_final);
		}
		

		
		
		System.out.println("\n\n[AdminChoiceServlet]   --------------  SERVLET ACTION REQUEST is ("+action+")");
		
		
			switch (action) { 
			
			case "return":
				returnToMainMenu(request, response);
				break;
			case "logout":
				logoutApplication(request, response);
				break;
			case "student_records":
				openStudentEditor(request, response);
				break;
			case "teacher_records":
				openTeacherEditor(request, response);
				break;
			case "subject_records":
				openSubjectEditor(request, response);
				break;
			case "classSession_records":
				openClassSessionEditor(request, response);
				break;
			default:
				logoutApplication(request, response);
				break;
			}
		
	}

	private void returnToMainMenu(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

				RequestDispatcher dispatcher = request.getRequestDispatcher("admin-choice-screen.jsp");
				dispatcher.forward(request, response);
	}
	
	
	private void logoutApplication(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
	 			new MockDataGen().createMockData(); // ONLY RUN ONCE
	 	
				RequestDispatcher dispatcher = request.getRequestDispatcher("app-login.jsp");
				dispatcher.forward(request, response);
	}
	
	
	private void openStudentEditor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

				RequestDispatcher dispatcher = request.getRequestDispatcher("student-records-form.jsp");
				dispatcher.forward(request, response);
				
	}
	
	private void openTeacherEditor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

				RequestDispatcher dispatcher = request.getRequestDispatcher("teacher-records-form.jsp");
				dispatcher.forward(request, response);
				
	}
	private void openSubjectEditor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

				RequestDispatcher dispatcher = request.getRequestDispatcher("subject-records-form.jsp");
				dispatcher.forward(request, response);
				
	}
	private void openClassSessionEditor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

				RequestDispatcher dispatcher = request.getRequestDispatcher("classsession-records-form.jsp");
				dispatcher.forward(request, response);
				
	}
}