package com.simplilearn.learners.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.simplilearn.learners.entities.ClassSession;
import com.simplilearn.learners.util.HibernateUtil;

/**
 * @author kevin casey
 *
 */
public class ClassSessionDao {

	/**
	 * @param id
	 * @return
	 */
	public ClassSession getClassSession(int id) {

		Transaction transaction = null;
		ClassSession classsession = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// --------------------------------------
			transaction = session.beginTransaction();
			// --------------------------------------
			classsession = session.get(ClassSession.class, id);
			// --------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return classsession;
	}

	
	/**
	 * @param id
	 * @return
	 */
	public static ClassSession getClassSessionById(int id) {
		
		Transaction transaction = null;
		ClassSession classsession = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// --------------------------------------
			transaction = session.beginTransaction();
			// --------------------------------------
			classsession = session.get(ClassSession.class, id);
			// --------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return classsession;
	}

	
	
	 
	/**
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<ClassSession> getAllClassList() {

		Transaction transaction = null;
		List<ClassSession> listOfClassSession = null;
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// --------------------------------------
			transaction = session.beginTransaction();
			// --------------------------------------
			listOfClassSession = session.createQuery("from ClassSession").getResultList();
			// --------------------------------------
			transaction.commit();
			
		} catch (Exception e) {
			if (transaction != null) {
				//transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfClassSession;
	}
	
	
	/**
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<ClassSession> getAllClassSession() {

		Transaction transaction = null;
		List<ClassSession> listOfClassSession = null;
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// --------------------------------------
			transaction = session.beginTransaction();
			// --------------------------------------
			listOfClassSession = session.createQuery("from ClassSession").getResultList();
			// --------------------------------------
			transaction.commit();
			
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfClassSession;
	}

	/**
	 * @param classsession
	 */
	public void saveClassSession(ClassSession classsession) {

		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// --------------------------------------
			transaction = session.beginTransaction();
			// --------------------------------------
			session.save(classsession);
			// --------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}

	}

	/**
	 * @param classsession
	 */
	public void updateClassSession(ClassSession classsession) {

		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// --------------------------------------
			transaction = session.beginTransaction();
			// --------------------------------------
			session.update(classsession);
			// --------------------------------------
			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	/**
	 * @param id
	 */
	public void deleteClassSession(int id) {

		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// --------------------------------------
			transaction = session.beginTransaction();
			// --------------------------------------
			ClassSession classsession = session.get(ClassSession.class, id);
			if (classsession != null) {
				session.delete(classsession);
				System.out.println("classsession is deleted");
			}
			// --------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
}