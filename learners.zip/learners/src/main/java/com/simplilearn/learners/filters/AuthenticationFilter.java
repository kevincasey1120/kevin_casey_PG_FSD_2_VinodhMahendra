package com.simplilearn.learners.filters;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

import com.simplilearn.learners.mock.MockDataGen;



public class AuthenticationFilter implements Filter {

	  public void init(FilterConfig filterConfig) throws ServletException {   }
	  
	    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chainObj) throws IOException, ServletException {
	 
	        RequestDispatcher rdObj = null;
	        PrintWriter out = resp.getWriter();
	        
	        out.write("<html><body><div id='servletResponse' style='text-align: center;'>");
	 
	        String password = req.getParameter("password");
	 
	        //======================================================
	        if(password != null && password.equals("secret")) {

	            chainObj.doFilter(req, resp);
	      
	        } else {
	        	  //======================================================
	            out.print("<p id='errMsg' style='color: red; font-size: 50px;'>-------------  INVALID! LOGIN ATTEMPT  ------------</p>");  
	            rdObj = req.getRequestDispatcher("app-login.jsp");  
	            rdObj.include(req, resp);  
	        }
	 
	        out.write("</div></body></html>");
	        out.close();
	    }
	 
	    public void destroy() { }
}
