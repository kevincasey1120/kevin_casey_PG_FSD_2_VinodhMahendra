package com.simplilearn.learners.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="classsessions")
public class ClassSession {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	protected int id;
	
	@Column(name="teacherid")
	protected int teacherid;
	
	@Column(name="subjectid")
	protected int subjectid;

	
	
	public ClassSession() {}
	
	public ClassSession(int teacherid, int subjectid) {
		super();
		this.teacherid = teacherid;
		this.subjectid = subjectid;
	}


	public ClassSession(int id, int teacherid, int subjectid) {
		super();
		this.id = id;
		this.teacherid = teacherid;
		this.subjectid = subjectid;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getTeacherid() {
		return teacherid;
	}


	public void setTeacherid(int teacherid) {
		this.teacherid = teacherid;
	}


	public int getSubjectid() {
		return subjectid;
	}


	public void setSubjectid(int subjectid) {
		this.subjectid = subjectid;
	}
}