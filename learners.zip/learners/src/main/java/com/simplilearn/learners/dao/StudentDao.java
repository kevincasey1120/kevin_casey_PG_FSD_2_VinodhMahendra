package com.simplilearn.learners.dao;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.Transaction;

import com.simplilearn.learners.entities.Student;
import com.simplilearn.learners.util.HibernateUtil;


/**
 * @author kevin casey
 *
 */
public class StudentDao {


	/**
	 * @param id
	 * @return
	 */
	public Student getStudent(int id) {

		Transaction transaction = null;
		Student student = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			student = session.get(Student.class, id);
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return student;
	}
	
	
	/**
	 * @param id
	 * @return
	 */
	public static Student getStudentById(int id) {

		Transaction transaction = null;
		Student student = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			student = session.get(Student.class, id);
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return student;
	}
	
	
	
	/**
	 * @param id
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Student> getStudentsWithClassId(int classid) {

		Transaction transaction = null;
		List<Student> listOfStudent = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			
			listOfStudent = session.createQuery("from Student WHERE classid ="+classid+"").getResultList();
			System.out.println("Student DAO]  --getStudentsWithClassId--   classid("+classid+")      list size = "+listOfStudent.size());

		
			//listOfStudent = session.createQuery("from Student").getResultList();
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfStudent;
	}
	
	/**
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Student> getAllStudentList() {

		Transaction transaction = null;
		List<Student> listOfStudent = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			listOfStudent = session.createQuery("from Student").getResultList();
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfStudent;
	}
	
	
	/**
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Student> getAllStudent() {

		Transaction transaction = null;
		List<Student> listOfStudent = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			listOfStudent = session.createQuery("from Student").getResultList();
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfStudent;
	}
	
	
	/**
	 * @param student
	 */
	public void saveStudent(Student student) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			session.save(student);
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}


	/**
	 * @param student
	 */
	public void updateStudent(Student student) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			session.update(student);
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}


	/**
	 * @param id
	 */
	public void deleteStudent(int id) {

		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			Student student = session.get(Student.class, id);
			if (student != null) {
				session.delete(student);
				System.out.println("student is deleted");
			}
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

}