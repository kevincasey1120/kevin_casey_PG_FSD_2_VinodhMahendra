package com.simplilearn.learners.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.simplilearn.learners.dao.StudentDao;
import com.simplilearn.learners.entities.Student;
import com.simplilearn.learners.entities.Teacher;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;



@WebServlet("/student-servlet")

public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private StudentDao studentDao;
	
	public void init() {
		studentDao = new StudentDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	
		
		String action = "";

		if (request.getParameterMap() != null && request.getParameterMap().size() > 0) {

			Map<String, String[]> parameters = request.getParameterMap();

			// ---------------------------------------------------
			int subjectid = -1;
			int teacherid = -1;

			// ---------------------------------------------------
			for (String parameter : parameters.keySet()) {

				String[] values = parameters.get(parameter);

				for (String val : values) {

					System.out.println(
							"[StudentServlet]    PARAMETER SET --->  (" + parameter + ")   (" + val + ")");
				}

			}
		} else {
			System.out.println("[StudentServlet]  ---->  NO PARAMETERS ARE SET  <---");
		}

		
	
		
		//----------------------------------------------------
		if(request.getServletPath() != null && request.getServletPath().equals("list")) {
			action = "list";
			
		}else {
			if(request.getParameterMap().containsKey("choice")) {
				action = request.getParameter("choice").toString();
			}
		}
		

		System.out.println("[StudentServlet]   SERVLET ACTION REQUEST is ("+action+")");
		
		
		//----------------------------------------------------
		if(action.contains("id=")) {
			//--------------------------
			String[] array = action.split("\\?");
			action = array[0];
			
			//--------------------------
			int id_final = Integer.parseInt(array[1].replace("id=", ""));
			System.out.println("[StudentServlet : doGet]  ----------------    array[0]= "+array[0]+"       id_final= "+id_final);
			request.setAttribute("id", id_final);
		}
		
		
		try {
			switch (action) { 
			case "new":
				showNewForm(request, response);
				break;
			case "insert":
				insertStudent(request, response);
				break;
			case "delete":
				deleteStudent(request, response);
				break;
			case "edit":
				showEditForm(request, response);
				break;
			case "update":
				updateStudent(request, response);
				break;
			case "list":
				listStudent(request, response);
				break;
			default:
				listStudent(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listStudent(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Student> listStudent = studentDao.getAllStudent();
		request.setAttribute("listStudent", listStudent);
		RequestDispatcher dispatcher = request.getRequestDispatcher("student-records-form.jsp"); // was student-records-listing.jsp
		dispatcher.forward(request, response);
	}

	
	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

				RequestDispatcher dispatcher = request.getRequestDispatcher("student-records-form.jsp");
				dispatcher.forward(request, response);
				
	}

	
	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {

		System.out.println("\n\n[StudentServlet]   request.getAttribute(\"id\")  ==  ("+request.getAttribute("id")+")");
		
		int id = (int) request.getAttribute("id");
		
		Student existingStudent = studentDao.getStudent(id);
		
		if(existingStudent == null) {
			System.out.println("[StudentServlet]  existingStudent ==  -NULL-");
		}else {
			System.out.println("[StudentServlet]  existingStudent ==  ( "+existingStudent.getLastname()+" "+existingStudent.getLastname()+" )");
		}
		
		
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("student-records-listing.jsp");
		request.setAttribute("student", existingStudent);
		dispatcher.forward(request, response);
		
	}

	
	

	
	
	
	private void insertStudent(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {

		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String email = request.getParameter("email");
		double gpa = Double.parseDouble(request.getParameter("gpa"));
		int classid = Integer.parseInt(request.getParameter("classid"));
		
		Student newStudent = new Student(firstname, lastname, email, gpa, classid);
		studentDao.saveStudent(newStudent);
		

		try {
			listStudent(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	
	
	private void updateStudent(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		
		int id = (int) request.getAttribute("id");
		
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String email = request.getParameter("email");
		double gpa = Double.parseDouble(request.getParameter("gpa"));
		int classid = Integer.parseInt(request.getParameter("classid"));
		
		
		
		
		
		Student student = new Student(id, firstname, lastname, email, gpa, classid);
		studentDao.updateStudent(student);
	
		try {
			listStudent(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	private void deleteStudent(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		
		
		int id = (int) request.getAttribute("id");
		
		studentDao.deleteStudent(id);

		try {
			listStudent(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}