package com.simplilearn.learners.dao;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.Transaction;

import com.simplilearn.learners.entities.Subject;
import com.simplilearn.learners.entities.Teacher;
import com.simplilearn.learners.util.HibernateUtil;


/**
 * @author kevin casey
 *
 */
public class TeacherDao {


	/**
	 * @param id
	 * @return
	 */
	public Teacher getTeacher(int id) {

		Transaction transaction = null;
		Teacher teacher = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			teacher = session.get(Teacher.class, id);
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return teacher;
	}
	
	
	
	/**
	 * @param id
	 * @return
	 */
	public static Teacher getTeacherById(int id) {

		Transaction transaction = null;
		Teacher teacher = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			teacher = session.get(Teacher.class, id);
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return teacher;
	}
	
	
	
	/**
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Teacher> getAllTeacherList() {

		Transaction transaction = null;
		List<Teacher> listOfTeacher = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			listOfTeacher = session.createQuery("from Teacher").getResultList();
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfTeacher;
	}
	
	
	/**
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Teacher> getAllTeacher() {

		Transaction transaction = null;
		List<Teacher> listOfTeacher = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			listOfTeacher = session.createQuery("from Teacher").getResultList();
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfTeacher;
	}
	
	
	/**
	 * @param teacher
	 */
	public void saveTeacher(Teacher teacher) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			session.save(teacher);
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	
	


	/**
	 * @param teacher
	 */
	public void updateTeacher(Teacher teacher) {
		
		Transaction transaction = null;
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			session.update(teacher);
			//--------------------------------------
			transaction.commit();
			
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}


	/**
	 * @param id
	 */
	public void deleteTeacher(int id) {

		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			Teacher teacher = session.get(Teacher.class, id);
			if (teacher != null) {
				session.delete(teacher);
				System.out.println("teacher is deleted");
			}
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

}