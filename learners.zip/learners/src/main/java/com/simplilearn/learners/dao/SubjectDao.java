package com.simplilearn.learners.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.simplilearn.learners.entities.Student;
import com.simplilearn.learners.entities.Subject;
import com.simplilearn.learners.util.HibernateUtil;


/**
 * @author kevin casey
 *
 */
public class SubjectDao {


	/**
	 * @param id
	 * @return
	 */
	public Subject getSubject(int id) {

		Transaction transaction = null;
		Subject subject = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			subject = session.get(Subject.class, id);
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return subject;
	}
	
	
	/**
	 * @param id
	 * @return
	 */
	public static Subject getStubjectById(int id) {

		Transaction transaction = null;
		Subject subject = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			subject = session.get(Subject.class, id);
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return subject;
	}
	
	
	
	/**
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static List<Subject> getAllSubjectList() {

		Transaction transaction = null;
		List<Subject> listOfSubject = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			listOfSubject = session.createQuery("from Subject").getResultList();
			//--------------------------------------
			transaction.commit();
			
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfSubject;
	}
	
	
	/**
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Subject> getAllSubject() {

		Transaction transaction = null;
		List<Subject> listOfSubject = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			listOfSubject = session.createQuery("from Subject").getResultList();
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfSubject;
	}
	
	
	/**
	 * @param subject
	 */
	public void saveSubject(Subject subject) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			session.save(subject);
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	
	


	/**
	 * @param subject
	 */
	public void updateSubject(Subject subject) {
		
		Transaction transaction = null;
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			session.update(subject);
			//--------------------------------------
			transaction.commit();
			
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}


	/**
	 * @param id
	 */
	public void deleteSubject(int id) {

		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			//--------------------------------------
			transaction = session.beginTransaction();
			//--------------------------------------
			Subject subject = session.get(Subject.class, id);
			if (subject != null) {
				session.delete(subject);
				System.out.println("subject is deleted");
			}
			//--------------------------------------
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

}