package com.simplilearn.learners.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.simplilearn.learners.dao.SubjectDao;
import com.simplilearn.learners.entities.Subject;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;



@WebServlet("/subject-servlet")

public class SubjectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private SubjectDao subjectDao;
	
	public void init() {
		subjectDao = new SubjectDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	
		String action = "";

		//----------------------------------------------------
		if(request.getParameterMap() != null && request.getParameterMap().size() > 0) {
			Map<String, String[]> parameters = request.getParameterMap();
			for(String parameter : parameters.keySet()) {
				System.out.println("[SubjectServlet]    PARAMETER SET --->    ("+parameters.get(parameter)+")");
				// String[] values = parameters.get(parameter);
			}
		}else {
			System.out.println("[SubjectServlet]  ---->  NO PARAMETERS ARE SET  <---");
		}
		
		
		//----------------------------------------------------
		if(request.getServletPath() != null && request.getServletPath().equals("list")) {
			action = "list";
			
		}else {
			if(request.getParameterMap().containsKey("choice")) {
				action = request.getParameter("choice").toString();
			}
		}
		

		System.out.println("[SubjectServlet]   SERVLET ACTION REQUEST is ("+action+")");
		
		
		//----------------------------------------------------
		if(action.contains("id=")) {
			//--------------------------
			String[] array = action.split("\\?");
			action = array[0];
			
			//--------------------------
			int id_final = Integer.parseInt(array[1].replace("id=", ""));
			System.out.println("[SubjectServlet : doGet]  ----------------    array[0]= "+array[0]+"       id_final= "+id_final);
			request.setAttribute("id", id_final);
		}
		
		
		try {
			switch (action) { 
			case "new":
				showNewForm(request, response);
				break;
			case "insert":
				insertSubject(request, response);
				break;
			case "delete":
				deleteSubject(request, response);
				break;
			case "edit":
				showEditForm(request, response);
				break;
			case "update":
				updateSubject(request, response);
				break;
			case "list":
				listSubject(request, response);
				break;
			default:
				listSubject(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listSubject(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Subject> listSubject = subjectDao.getAllSubject();
		request.setAttribute("listSubject", listSubject);
		RequestDispatcher dispatcher = request.getRequestDispatcher("subject-records-form.jsp"); // was subject-records-listing.jsp
		dispatcher.forward(request, response);
	}

	
	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

				RequestDispatcher dispatcher = request.getRequestDispatcher("subject-records-form.jsp");
				dispatcher.forward(request, response);
				
	}

	
	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {

		int id = (int) request.getAttribute("id");
		
		Subject existingSubject = subjectDao.getSubject(id);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("subject-records-listing.jsp");
		request.setAttribute("subject", existingSubject);
		dispatcher.forward(request, response);
		
	}

	
	private void insertSubject(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		String title = request.getParameter("title");
		Subject newSubject = new Subject(title);
		subjectDao.saveSubject(newSubject);
	
		
		try {
			listSubject(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	
	
	private void updateSubject(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		
		int id = (int) request.getAttribute("id");
		
		String title = request.getParameter("title");
		
		Subject newSubject = new Subject(id, title);
		subjectDao.updateSubject(newSubject);
	
		try {
			listSubject(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	private void deleteSubject(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		
		
		int id = (int) request.getAttribute("id");
		
		subjectDao.deleteSubject(id);

		try {
			listSubject(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}