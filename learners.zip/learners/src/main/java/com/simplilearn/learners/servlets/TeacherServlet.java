package com.simplilearn.learners.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.simplilearn.learners.dao.TeacherDao;
import com.simplilearn.learners.entities.Teacher;

import java.sql.SQLException;

import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;



@WebServlet("/teacher-servlet")

public class TeacherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TeacherDao teacherDao;
	
	public void init() {
		teacherDao = new TeacherDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	
		String action = "";
		
		//----------------------------------------------------
		if(request.getParameterMap() != null && request.getParameterMap().size() > 0) {
			Map<String, String[]> parameters = request.getParameterMap();
			for(String parameter : parameters.keySet()) {
				System.out.println("[TeacherServlet]    PARAMETER SET --->    ("+parameters.get(parameter)+")");
				// String[] values = parameters.get(parameter);
			}
		}else {
			System.out.println("[TeacherServlet]  ---->  NO PARAMETERS ARE SET  <---");
		}
		
		
		//----------------------------------------------------
		if(request.getServletPath() != null && request.getServletPath().equals("list")) {
			action = "list";
			
		}else {
			if(request.getParameterMap().containsKey("choice")) {
				action = request.getParameter("choice").toString();
			}
		}
		

		System.out.println("[TeacherServlet]   SERVLET ACTION REQUEST is ("+action+")");
		
		
		//----------------------------------------------------
		if(action.contains("id=")) {
			//--------------------------
			String[] array = action.split("\\?");
			action = array[0];
			
			//--------------------------
			int id_final = Integer.parseInt(array[1].replace("id=", ""));
			System.out.println("[TeacherServlet : doGet]  ----------------    array[0]= "+array[0]+"       id_final= "+id_final);
			request.setAttribute("id", id_final);
		}
		
		
		try {
			switch (action) { 
			case "new":
				showNewForm(request, response);
				break;
			case "insert":
				insertTeacher(request, response);
				break;
			case "delete":
				deleteTeacher(request, response);
				break;
			case "edit":
				showEditForm(request, response);
				break;
			case "update":
				updateTeacher(request, response);
				break;
			case "list":
				listTeacher(request, response);
				break;
			default:
				listTeacher(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listTeacher(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Teacher> listTeacher = teacherDao.getAllTeacher();
		request.setAttribute("listTeacher", listTeacher);
		RequestDispatcher dispatcher = request.getRequestDispatcher("teacher-records-form.jsp"); // was teacher-records-listing.jsp
		dispatcher.forward(request, response);
	}

	
	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

				RequestDispatcher dispatcher = request.getRequestDispatcher("teacher-records-form.jsp");
				dispatcher.forward(request, response);
				
	}

	
	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {

		int id = (int) request.getAttribute("id");
		
		Teacher existingTeacher = teacherDao.getTeacher(id);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("teacher-records-listing.jsp");
		request.setAttribute("teacher", existingTeacher);
		dispatcher.forward(request, response);
		
	}

	
	private void insertTeacher(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {

		String title = request.getParameter("title");
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String email = request.getParameter("email");
		Teacher newTeacher = new Teacher(title, firstname, lastname, email);
		teacherDao.saveTeacher(newTeacher);
		
		
		try {
			listTeacher(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	
	
	private void updateTeacher(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		
		int id = (int) request.getAttribute("id");
		
		String title = request.getParameter("title");
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String email = request.getParameter("email");
		
		Teacher newTeacher = new Teacher(id, title, firstname, lastname, email);
		teacherDao.updateTeacher(newTeacher);
	

		try {
			listTeacher(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	private void deleteTeacher(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		
		
		int id = (int) request.getAttribute("id");
		
		teacherDao.deleteTeacher(id);

		try {
			listTeacher(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}