CREATE DATABASE 'learners';
USE learners;

CREATE TABLE `students` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `gpa` double DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `classid` int DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `teachers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);


CREATE TABLE `subjects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `classsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subjectid` int NOT NULL,
  `teacherid` int DEFAULT NULL,
  PRIMARY KEY (`id`)
);